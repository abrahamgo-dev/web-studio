const PROJECTS = [
  {
    name: "Northbeam Finance",
    kind: "Fintech dashboard",
    year: "2026",
  },
  {
    name: "Loom & Co.",
    kind: "E-commerce rebuild",
    year: "2025",
  },
  {
    name: "Halcyon Health",
    kind: "Marketing site + booking",
    year: "2025",
  },
  {
    name: "Ferrous Logistics",
    kind: "Internal ops tool",
    year: "2025",
  },
];

export default function Work() {
  return (
    <section id="work" className="relative border-t border-line">
      <div className="mx-auto max-w-6xl px-6 py-24 md:px-10 md:py-32">
        <div className="mb-14 md:mb-20">
          <h2 className="font-[family-name:var(--font-display)] text-3xl font-semibold tracking-tight text-ink md:text-4xl">
            Selected work
          </h2>
          <p className="mt-3 max-w-md text-sm text-ink-dim">
            Placeholder case studies — swap these for your own projects, or
            leave them as a template while you build your first case study.
          </p>
        </div>

        <div className="divide-y divide-line border-y border-line">
          {PROJECTS.map((project) => (
            <a
              key={project.name}
              href="#contact"
              className="group flex flex-col items-start justify-between gap-2 py-7 transition-colors hover:bg-white/[0.02] sm:flex-row sm:items-center sm:px-4"
            >
              <div className="flex items-baseline gap-4">
                <span className="font-[family-name:var(--font-display)] text-xl font-medium text-ink transition-colors group-hover:text-accent-bright sm:text-2xl">
                  {project.name}
                </span>
                <span className="text-sm text-ink-dim">{project.kind}</span>
              </div>
              <span className="text-sm text-ink-dim">{project.year}</span>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}
