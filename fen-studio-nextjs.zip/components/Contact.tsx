import { ArrowUpRight, Mail } from "lucide-react";

export default function Contact() {
  return (
    <section id="contact" className="relative border-t border-line">
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="aura absolute left-1/2 top-1/2 h-[420px] w-[420px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-accent/25 blur-[110px]" />
      </div>

      <div className="relative mx-auto max-w-3xl px-6 py-24 text-center md:px-10 md:py-32">
        <h2 className="text-balance font-[family-name:var(--font-display)] text-4xl font-semibold tracking-tight text-ink md:text-5xl">
          Tell us what you&apos;re building.
        </h2>
        <p className="mx-auto mt-5 max-w-md text-balance text-ink-dim">
          A short reply, usually within a day — with the honest version of
          whether we&apos;re the right fit.
        </p>

        <div className="mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row">
          <a
            href="mailto:hello@fenstudio.com"
            className="inline-flex w-full items-center justify-center gap-2 rounded-full bg-accent px-8 py-3.5 text-sm font-medium text-white transition-colors hover:bg-accent/85 sm:w-auto"
          >
            <Mail className="h-4 w-4" />
            hello@fenstudio.com
          </a>
          <a
            href="#work"
            className="inline-flex w-full items-center justify-center gap-1.5 rounded-full border border-line px-8 py-3.5 text-sm font-medium text-ink transition-colors hover:border-accent-bright/60 hover:text-accent-bright sm:w-auto"
          >
            View the work
            <ArrowUpRight className="h-4 w-4" />
          </a>
        </div>
      </div>
    </section>
  );
}
