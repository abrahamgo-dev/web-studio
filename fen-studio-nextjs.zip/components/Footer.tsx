export default function Footer() {
  return (
    <footer className="border-t border-line">
      <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 px-6 py-8 text-xs text-ink-dim md:flex-row md:px-10">
        <span>© {new Date().getFullYear()} Fen Studio. All rights reserved.</span>
        <div className="flex gap-6">
          <a href="#top" className="transition-colors hover:text-ink">
            Back to top
          </a>
          <a href="#contact" className="transition-colors hover:text-ink">
            Contact
          </a>
        </div>
      </div>
    </footer>
  );
}
