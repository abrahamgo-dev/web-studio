import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Fen Studio — Web Design & Digital Solutions",
  description:
    "Fen Studio builds fast, distinctive websites and digital products for founders who refuse to look like a template.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es">
      <body className="antialiased">{children}</body>
    </html>
  );
}
